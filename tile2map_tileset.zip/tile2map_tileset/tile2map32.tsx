<?xml version="1.0" encoding="UTF-8"?>
<tileset name="tile2map32" tilewidth="32" tileheight="32">
 <image source="tile2map32.png" width="128" height="10560"/>
</tileset>
