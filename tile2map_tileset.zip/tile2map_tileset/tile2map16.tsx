<?xml version="1.0" encoding="UTF-8"?>
<tileset name="tile2map16" tilewidth="16" tileheight="16">
 <image source="tile2map16.png" width="64" height="5280"/>
</tileset>
